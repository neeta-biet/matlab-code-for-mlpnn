clc;
clear all;
close all;
inputs= xlsread('input.xlsx');
output= xlsread('target.xlsx');
