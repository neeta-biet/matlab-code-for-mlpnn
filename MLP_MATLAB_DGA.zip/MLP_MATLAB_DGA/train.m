

clear;
clc;

[n tx table] = xlsread('data.xlsx');

data=[];

for i=1:length(table)
    
    record=table{i,1};
    ndata=[];
    cnt=1;
    k=1;
    s=[];
    while k<=length(record)
        ch=record(k);
        if strcmp(ch,',')%Compare String
           ndata(cnt,1)=str2num(s);
           cnt=cnt+1;
           s='';
        else
            s=[s ch];
        end
                
        k=k+1;
    end
    ndata(cnt,1)=str2num(s);
    
    data(:,i)=ndata;
end

inputs=data(2:end,1:2:end);
oututs=[];
cnt=1;
for i=1:2:215
    
    n=data(1,i) ;
    if n==1
        outputs(:,cnt)=[0; 0; 1];
        cnt=cnt+1;
    end
    if n==2
        outputs(:,cnt)=[0; 1; 0];
        cnt=cnt+1;
    end
    
     if n==3
        outputs(:,cnt)=[1; 0; 0];
        cnt=cnt+1;
    end
end

nprtool
%nftool
q=input('Enter any key to continue');

score=0;
for i=2:2:215
    x=find(compet(sim(net,data(2:end,i))));
    if x==data(1,i)
        score=score+1;
    end
end
ans=score/107;
x=0;
x=ans*100;
disp(['the accuracy of ann is in %=',num2str(x)]);
